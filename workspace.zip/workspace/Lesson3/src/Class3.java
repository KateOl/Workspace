
public class Class3 {

	public static void main(String[] args) {
		
	}

}
