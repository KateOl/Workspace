package pack1;

import pack2.Summ;

public class Account {

private long acc; // ����� ���������� �����
private int accNumber;

String curMoney; // ������

Summ sumOfMoney = new Summ();   

    public static void main(String[] args) {
       
    	Account obj = new Account();
    	
    	obj.sumOfMoney.setSumMoney(100000);
    	obj.sumOfMoney.setCurrencyType("2");
    	
    	long x;
    	String y;
    	
    	x= obj.sumOfMoney.getSumMoney();
    	y= obj.sumOfMoney.getCurrencyType();
    	
    	System.out.println(x);
    	System.out.println(y);
        
    }

}