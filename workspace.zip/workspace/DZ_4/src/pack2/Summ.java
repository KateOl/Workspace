package pack2;

public class Summ {

	private long sumMoney;
	private short codCurr;
	private short codTypeOperation;
	
	public static void main(String[] args) {
	
		

	}

	public void setSumMoney(long sumMoney) {
		this.sumMoney = sumMoney;
	}

	public void setCodCurr(short codCurr) {
		this.codCurr = codCurr;
	}

	public void setCodTypeOperation(short codTypeOperation) {
		this.codTypeOperation = codTypeOperation;
	}

	

}
