import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;


public class GUI1 {

	public static void main(String[] args) {
		JFrame frWin = new JFrame ("������� �����");
		
		frWin.setLayout(null);
		
		JLabel label = new JLabel("����������");
		label.setBounds(30, 50, 100, 20);
		frWin.add(label);
		
		JTextField text = new JTextField("����� ������ ���");
		text.setBounds(140, 50, 120, 20);
		frWin.add(text);
		
		JButton button = new JButton("Ok");
		button.setBounds(120, 120, 70, 30);
		frWin.add(button);
		
		frWin.setSize(300, 200);
		frWin.setLocationRelativeTo(null);
		frWin.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		
        frWin.setVisible(true);
	}

}
